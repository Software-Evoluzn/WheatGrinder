import React from 'react';
import {
  View,
  Image,
  Text,
  TouchableOpacity,
  StyleSheet,
  StatusBar,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import Feather from 'react-native-vector-icons/Feather';



const NEXT_ROUTE = 'SelectGrain';

const ReadyToCleanScreen = ({ navigation, route }) => {
  const handleReady = () => {
    const grainId = route?.params?.grainId;
    if (navigation?.navigate) {
      navigation.navigate(NEXT_ROUTE, grainId ? { grainId } : undefined);
    }
  };

  return (
    <SafeAreaView style={styles.safe} edges={['top', 'left', 'right', 'bottom']}>
      <StatusBar barStyle="dark-content" backgroundColor="#FFFFFF" />

      <View style={styles.centerContent}>
        {/* <Image
          source={require('../assets/images/Softel Millet mill logo 2.png')}
          style={styles.millLogo}
          resizeMode="contain"
        /> */}

        <View style={styles.iconBox}>
          <Feather name="settings" size={40} color="#55327A" />
        </View>

        <Text style={styles.message}>Press READY to initiate the self-cleaning process</Text>

        <TouchableOpacity
          style={styles.readyButton}
          activeOpacity={0.85}
          onPress={handleReady}
        >
          <Text style={styles.readyButtonText}>READY</Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
};

export default ReadyToCleanScreen;

const styles = StyleSheet.create({
  safe: {
    flex: 1,
    backgroundColor: '#FFFFFF',
  },

  centerContent: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 32,
  },

  millLogo: {
    width: 170,
    height: 90,
    marginBottom: 30,
  },

  iconBox: {
    width: 88,
    height: 88,
    borderRadius: 18,
    borderWidth: 1.5,
    borderColor: '#D9CFE6',
    backgroundColor: '#FBFAFD',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 28,
  },

  message: {
    fontSize: 18,
    fontWeight: '700',
    color: '#3E1A5B',
    textAlign: 'center',
    marginBottom: 28,
    lineHeight: 24,
  },

  readyButton: {
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#522D70',
    paddingVertical: 14,
    paddingHorizontal: 48,
    borderRadius: 12,

    shadowColor: '#000000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.12,
    shadowRadius: 8,
    elevation: 3,
  },

  readyButtonText: {
    color: '#FFFFFF',
    fontSize: 15,
    fontWeight: '700',
    letterSpacing: 1.5,
  },
});