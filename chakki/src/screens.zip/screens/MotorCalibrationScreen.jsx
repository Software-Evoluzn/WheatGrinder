import React, { useState, useEffect, useRef } from 'react';
import {
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  Image,
  SafeAreaView,
  StatusBar,
  Animated,
  Easing,
  ActivityIndicator,
} from 'react-native';

const MotorCalibrationScreen = ({ navigation }) => {
  const [isCalibrated, setIsCalibrated] = useState(false);
  const rotateAnim = useRef(new Animated.Value(0)).current;

  // Continuous spinner animation during calibration
  useEffect(() => {
    let rotationAnimation;
    if (!isCalibrated) {
      rotationAnimation = Animated.loop(
        Animated.timing(rotateAnim, {
          toValue: 1,
          duration: 1500,
          easing: Easing.linear,
          useNativeDriver: true,
        })
      );
      rotationAnimation.start();
    }

    // Simulate Motor Calibration process completion after 3 seconds
    const timer = setTimeout(() => {
      setIsCalibrated(true);
    }, 3000);

    return () => {
      if (rotationAnimation) rotationAnimation.stop();
      clearTimeout(timer);
    };
  }, [isCalibrated, rotateAnim]);

  const spin = rotateAnim.interpolate({
    inputRange: [0, 1],
    outputRange: ['0deg', '360deg'],
  });

  const handleNext = () => {
    if (navigation?.navigate) {
      navigation.navigate('CleaningProcessScreen');
    }
  };

  return (
    <SafeAreaView style={styles.safeArea}>
      <StatusBar barStyle="dark-content" backgroundColor="#FFFFFF" />
      <View style={styles.container}>

        {/* Top Header Logo
        <View style={styles.header}>
          <View />
          <Image
            source={require('../assets/images/Softel Millet mill logo 2.png')}
            style={styles.logo}
            resizeMode="contain"
          />
        </View> */}

        {/* Center Content Section */}
        <View style={styles.centerSection}>

          {!isCalibrated ? (
            /* STATE 1: CALIBRATION IN PROGRESS */
            <View style={styles.stateContainer}>
              <View style={styles.indicatorWrapper}>
                <Animated.View style={{ transform: [{ rotate: spin }] }}>
                  <ActivityIndicator size={64} color="#6C5CE7" />
                </Animated.View>
              </View>

              <Text style={styles.statusText}>
                MOTOR CALIBRATION STARTED
              </Text>
            </View>
          ) : (
            /* STATE 2: CALIBRATION COMPLETED */
            <View style={styles.stateContainer}>
              <View style={styles.successBadge}>
                <Text style={styles.checkmarkIcon}>✓</Text>
              </View>

              <Text style={styles.statusText}>
                MOTOR CALIBRATION COMPLETED
              </Text>

              {/* Green Action Button */}
              <TouchableOpacity
                style={styles.button}
                onPress={handleNext}
                activeOpacity={0.85}
              >
                <Text style={styles.buttonText}>NEXT</Text>
                <Text style={styles.arrowIcon}>➔</Text>
              </TouchableOpacity>
            </View>
          )}

        </View>

      </View>
    </SafeAreaView>
  );
};

export default MotorCalibrationScreen;

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: '#FFFFFF',
  },
  container: {
    flex: 1,
    backgroundColor: '#FFFFFF',
    paddingHorizontal: 24,
  },

  /* HEADER */
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingTop: 8,
  },
  logo: {
    width: 130,
    height: 60,
  },

  /* CENTER SECTION */
  centerSection: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingBottom: 40,
  },

  stateContainer: {
    alignItems: 'center',
    width: '100%',
  },

  /* PROGRESS SPINNER */
  indicatorWrapper: {
    width: 100,
    height: 100,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 36,
  },

  /* SUCCESS CHECKMARK BADGE */
  successBadge: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: '#0A8F44', // Solid Green
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 36,

    // Soft Shadow
    elevation: 4,
    shadowColor: '#0A8F44',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
  },
  checkmarkIcon: {
    color: '#FFFFFF',
    fontSize: 42,
    fontWeight: '800',
    marginTop: -2,
  },

  /* TYPOGRAPHY */
  statusText: {
    fontSize: 22,
    fontWeight: '800',
    color: '#2C2C2C',
    textAlign: 'center',
    letterSpacing: 2,
    maxWidth: 340,
    lineHeight: 32,
    marginBottom: 40,
  },

  /* BUTTON */
  button: {
    flexDirection: 'row',
    width: '100%',
    maxWidth: 200,
    height: 52,
    borderRadius: 14,
    backgroundColor: '#0A8F44', // Action Green
    justifyContent: 'center',
    alignItems: 'center',

    // Elevation Shadow
    elevation: 4,
    shadowColor: '#0A8F44',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
  },
  buttonText: {
    color: '#FFFFFF',
    fontSize: 17,
    fontWeight: '800',
    letterSpacing: 1.5,
    marginRight: 8,
  },
  arrowIcon: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: '700',
  },
});