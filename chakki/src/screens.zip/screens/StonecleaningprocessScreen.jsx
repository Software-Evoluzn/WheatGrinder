import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const StonecleaningprocessScreen = () => {
  return (
    <View>
      <Text>StonecleaningprocessScreen</Text>
    </View>
  )
}

export default StonecleaningprocessScreen

const styles = StyleSheet.create({})