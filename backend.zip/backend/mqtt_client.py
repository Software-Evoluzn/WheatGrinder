# mqtt_client.py
import paho.mqtt.client as mqtt
import json

MQTT_BROKER = "evoluzn.org"
MQTT_PORT = 18889
MQTT_USERNAME = "evzin_led"
MQTT_PASSWORD = "63I9YhMaXpa49Eb"

global_client = None

def on_connect(client, userdata, flags, rc):
    if rc == 0:
        print("MQTT connected successfully")
    else:
        print(f"MQTT connection failed. Error code: {rc}")

def on_message(client, userdata, msg):
    try:
        payload = msg.payload.decode("utf-8")
        print(f"MQTT Received | Topic: {msg.topic} | Payload: {payload}")
    except Exception as e:
        print(f"MQTT message processing error: {e}")

def start_mqtt():
    global global_client
    client = mqtt.Client()

    if MQTT_USERNAME and MQTT_PASSWORD:
        client.username_pw_set(MQTT_USERNAME, MQTT_PASSWORD)

    client.on_connect = on_connect
    client.on_message = on_message

    try:
        client.connect(MQTT_BROKER, MQTT_PORT, keepalive=60)
        client.loop_start()
        global_client = client
        return client
    except Exception as e:
        print(f"MQTT connection error: {e}")
        return None

# Generic helper function to publish dynamic payloads
def publish_message(topic, message_dict):
    global global_client
    if global_client and global_client.is_connected():
        try:
            payload = json.dumps(message_dict)
            global_client.publish(topic, payload, qos=1)
            print(f"MQTT Published | Topic: {topic} | Payload: {payload}")
            return True
        except Exception as e:
            print(f"Failed to publish MQTT message: {e}")
            return False
    print("MQTT client not connected")
    return False

# Function to dynamically subscribe to device topics: serial_number/#
def subscribe_to_device(serial_number):
    global global_client
    if global_client and global_client.is_connected():
        topic = f"{serial_number}/#"
        global_client.subscribe(topic)
        print(f"Subscribed dynamically to: {topic}")