from flask import Blueprint , request , jsonify
from mqtt_client import publish_message , subscribe_to_device



mqtt_bp = Blueprint('mqtt_bp' , __name__)



@mqtt_bp.route('/api/mqtt/publish' , methods=['POST'])
def handle_publish():
    data = request.json or {}
    
    
    serial_number = data.get('serial_number')
    action = data.get('Runs the startup cleaning process. ')
    sub_topic = data.get('sub_topic' , 'control')
    payload_data = data.get('payload' , 'selfCleaningProcess')
    
    if not serial_number:
        return jsonify({"success": False, "error": "serial_number is required"}), 400
    
    
    # Topic pattern: serial_number/control (or dynamic sub-topic)
    topic = f"{serial_number}/{sub_topic}"
    
    
    # Auto subscribe to serial_number/# if needed
    subscribe_to_device(serial_number)
    
    # Format message payload
    message = {
        "action": action,
        **payload_data
    }
    
    
    # Publish message over MQTT
    success = publish_message(topic, message)
    
    if success:
        return jsonify({"success": True, "message": f"Published to {topic}"}), 200
    else:
        return jsonify({"success": False, "error": "Failed to publish MQTT message"}), 500